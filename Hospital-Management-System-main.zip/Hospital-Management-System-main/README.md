<h1>Hospital-Management-System</h1>
<h3>A Java based dynamic web application using servlet (JDBC - Servlet) to manage the hospital staffs , doctors, patients.</h3>

<p> 
  A dynamic Web Portal used for Hospital Management to perform operations regarding staffs , doctors , patients , receptionist , security staff , cleaning staffs , nurses.
  A fully secured and email verified login and signup.
  Facility to book a room , make an appointment. 
</p>

<p> Here are some of the views of project below </p>
<br>
<div style="display:flex">
  
  <img src="./images/signup.PNG">
  <img src="./images/login.PNG">
  <img src="./images/Home.PNG">
  <img src="./images/Admin Panel.PNG">
  <img src="./images/roomsbooking.PNG">
</div>
